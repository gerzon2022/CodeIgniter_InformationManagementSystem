-- MariaDB dump 10.19  Distrib 10.5.12-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u321400137_barangay
-- ------------------------------------------------------
-- Server version	10.5.12-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `barangay_info`
--

DROP TABLE IF EXISTS `barangay_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barangay_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province` varchar(100) DEFAULT NULL,
  `town` text DEFAULT NULL,
  `brgy_name` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `starts` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `dashboard_text` text DEFAULT NULL,
  `dashboard_img` text DEFAULT NULL,
  `city_logo` text DEFAULT NULL,
  `brgy_logo` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barangay_info`
--

/*!40000 ALTER TABLE `barangay_info` DISABLE KEYS */;
INSERT INTO `barangay_info` VALUES (1,'Misamis Occidental','Oroquieta City','BARANGAY SAN VICENTE BAJO','+639304670686','admin@localbarangay.ml','2018','2022','\' MABUHAY BARANGAY SAN VICENTE BAJO \"','bg.png','city_logo.png','brgy-logo.png');
/*!40000 ALTER TABLE `barangay_info` ENABLE KEYS */;

--
-- Table structure for table `blotter`
--

DROP TABLE IF EXISTS `blotter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blotter` (
  `case_no` varchar(100) NOT NULL,
  `respondent` varchar(100) NOT NULL,
  `victim` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `location` text NOT NULL,
  `incident_date` datetime NOT NULL,
  `details` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`case_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blotter`
--

/*!40000 ALTER TABLE `blotter` DISABLE KEYS */;
INSERT INTO `blotter` VALUES ('00123','Rodwen Francisco','Allan Castaneda','Amicable','Altavas Poblacion','2021-08-17 04:00:00','Habang nagatikang si Allan hay sinita imaw ni Rodwen nga hilong.','Scheduled','2021-08-19 13:54:00'),('12324342','Tsukuyo','Ginsan','Amicable','baybay','2021-11-11 16:57:00','abugbug kay hubog','Active','2021-11-11 16:57:00');
/*!40000 ALTER TABLE `blotter` ENABLE KEYS */;

--
-- Table structure for table `cert_settings`
--

DROP TABLE IF EXISTS `cert_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cert_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flag` text DEFAULT NULL,
  `motto` text DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `watermark` text DEFAULT NULL,
  `color_bg` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cert_settings`
--

/*!40000 ALTER TABLE `cert_settings` DISABLE KEYS */;
INSERT INTO `cert_settings` VALUES (1,'flag.png','motto.png','signature.png','brgy-logo.png','rgba(216, 210, 28, 0.58)');
/*!40000 ALTER TABLE `cert_settings` ENABLE KEYS */;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` text DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `salutation` varchar(200) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
INSERT INTO `certificates` VALUES (8,'dbbd805ba29e0013394500bb40f24ac0.jpg','C E R T I F I C A T I O N','TO WHOM IT MAY CONCERN :','<p><span style=\"font-family: Calibri;\">This is to certify that </span><b>ALLAN L. CASTANEDA</b><span style=\"font-family: Calibri;\">, of legal age, male, married and a resident of Poblacion, Altavas, Aklan is a person of good moral character and conduct; that according to the record of this office, he/she has never been accused nor convicted of any crime, violation of legal orders, decrees, or any ordinance of this barangay.</span><br></p><p><b><span style=\"font-family: Calibri;\">THIS CERTIFICATION IS BEING ISSUED</span></b><span style=\"font-family: Calibri;\"> upon his/her request for the following purposes:</span><br></p><p><br></p><p>( ) Application for employment                                                              ( ) School Reference</p><p>( ) Passport / Overseas Travel Papers                                                   ( ) Processing of Calamity / Disaster</p><p>( ) Transaction with a bank                                                                     ( ) Police Clearance / NBI</p><p>( ) Loan / Lending Institution                                                                  ( ) Postal ID</p><p>( ) Travel / Transfer of Residence                                                           ( ) Others : Please specify : </p><p><br></p>','admin','2021-08-19 03:47:37'),(16,NULL,'Barangay Certificate',NULL,'                <p>Sample</p>\r\n            ','admin','2021-11-10 11:14:31'),(17,NULL,'Baranagay Certificate',NULL,'                <p>Sample</p>\r\n            ','admin','2021-11-10 11:23:35'),(18,NULL,'C E R T I F I C A T I O N',NULL,'This is to Certify that this project is nooiccee!!','admin','2021-12-15 01:17:58'),(19,NULL,'J A N I C E',NULL,'                <p>HI</p><p>THIS</p><p>IS</p><p>A&nbsp;</p><p>TEST</p><p>CERTIFICATE</p>\r\n            ','admin','2021-12-15 01:19:18');
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;

--
-- Table structure for table `chairmanship`
--

DROP TABLE IF EXISTS `chairmanship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chairmanship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chairmanship`
--

/*!40000 ALTER TABLE `chairmanship` DISABLE KEYS */;
INSERT INTO `chairmanship` VALUES (1,'PRESIDING OFFICER'),(3,'COMMITTEE ON HEALTH'),(4,'COMMITTEE ON APPROPRIATION'),(5,'COMMITTEE ON ENVIRONMENT'),(6,'COMMITTEE ON PEACE AND ORDER'),(7,'COMMITTEE ON EDUCATION'),(8,'COMMITTEE ON INFRASTRUCTURE'),(9,'COMMITTEE ON YOUTH DEVELOPMENT'),(10,'COMMITTEE ON GAD'),(11,'COMMITTEE ON AGRICULTURE'),(12,'COMMITTEE ON BAC'),(13,'COMMITTEE ON WAYS AND MEANS'),(14,'COMMITTEE ON VAW-C'),(15,'COMMITTEE ON SPORTS'),(16,'COMMITTEE ON APPROPRIATION / YOUTH DEVELOPMENT'),(17,'COMMITTEE ON HEALTH / SPORTS'),(18,'COMMITTEE ON INFRASTRUCTURE / BAC / WAYS AND MEANS'),(19,'COMMITTEE ON PEACE AND ORDER / SPORTS'),(20,'COMMITTEE ON VAW-C / COMMITTEE ON EDUCATION'),(21,'COMMITTEE ON ENVIRONMENT / GAD'),(23,'IT MEMBERS');
/*!40000 ALTER TABLE `chairmanship` ENABLE KEYS */;

--
-- Table structure for table `complainants`
--

DROP TABLE IF EXISTS `complainants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complainants` (
  `case_no` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `national_id` varchar(50) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `age` varchar(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  KEY `case_no` (`case_no`),
  CONSTRAINT `complainants_ibfk_1` FOREIGN KEY (`case_no`) REFERENCES `blotter` (`case_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complainants`
--

/*!40000 ALTER TABLE `complainants` DISABLE KEYS */;
INSERT INTO `complainants` VALUES ('00123','Allan Castaneda','','09203251234','Male','36','','Kalibo Aklan'),('12324342','Ginsan','','094859284593','Female','30','','Abugbug');
/*!40000 ALTER TABLE `complainants` ENABLE KEYS */;

--
-- Table structure for table `covid_status`
--

DROP TABLE IF EXISTS `covid_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `covid_status` (
  `resident_id` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `date_vaccinated` date DEFAULT NULL,
  `vaccinator_name` text DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `batch_no` varchar(100) DEFAULT NULL,
  `lot_no` varchar(100) DEFAULT NULL,
  `date_vaccinated_1` date DEFAULT NULL,
  `vaccinator_name_1` varchar(100) DEFAULT NULL,
  `manufacturer_1` text DEFAULT NULL,
  `batch_no_1` varchar(100) DEFAULT NULL,
  `lot_no_1` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  KEY `resident_id` (`resident_id`),
  CONSTRAINT `covid_status_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `covid_status`
--

/*!40000 ALTER TABLE `covid_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `covid_status` ENABLE KEYS */;

--
-- Table structure for table `house_number`
--

DROP TABLE IF EXISTS `house_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_number` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(100) DEFAULT NULL,
  `info` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=9590 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house_number`
--

/*!40000 ALTER TABLE `house_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `house_number` ENABLE KEYS */;

--
-- Table structure for table `id_settings`
--

DROP TABLE IF EXISTS `id_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `id_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `front` text DEFAULT NULL,
  `back` text DEFAULT NULL,
  `bg_color` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `id_settings`
--

/*!40000 ALTER TABLE `id_settings` DISABLE KEYS */;
INSERT INTO `id_settings` VALUES (1,'1e5e267b4875839a53e58f61e85b029d.png','fe44f74f667037a438d8b5d161c045dc.jpg','rgba(252, 241, 73, 0.9)');
/*!40000 ALTER TABLE `id_settings` ENABLE KEYS */;

--
-- Table structure for table `officials`
--

DROP TABLE IF EXISTS `officials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `officials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `chairmanship` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `termstart` date DEFAULT NULL,
  `termend` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `officials`
--

/*!40000 ALTER TABLE `officials` DISABLE KEYS */;
INSERT INTO `officials` VALUES (2,'FILOMENO D. REFOL I',1,3,'2021-05-08','2025-05-28','Active','b06f85f1a4fb81ca33c572df77f82c48.png'),(3,'TIFFANY LEIGH O. DOROTEO',16,1,'2021-05-15','2025-06-03','Active',NULL),(4,'KARL CHRISTOPHER D. QUIMPO',17,5,'2021-05-22','2025-04-30','Active',NULL),(5,'IRADIEL V. VILLANUEVA, JR.',18,6,'2021-05-01','2025-05-01','Active',NULL),(6,'BERNARD J\'PETE M. PANADERO',19,7,'2021-05-08','2025-05-08','Active',NULL),(7,'GINA P. CUSTODIO',20,8,'2021-05-08','2021-05-08','Active',NULL),(8,'EVELYN F. BELARMINO',21,9,'2021-05-08','2025-05-01','Active',NULL),(9,'FERMIN R. SUCGANG, JR.',11,10,'2021-05-22','2025-05-15','Active',NULL),(10,'AUGUSTIE T. PERLAS',22,4,'2021-05-01','2025-05-08','Active',NULL),(11,'VANGIE C. MORE',22,11,'2021-05-08','2025-05-15','Active',NULL),(12,'CHERYL ANN MAY A. DALIDA',22,12,'2021-05-01','2025-05-15','Active',NULL),(22,'Juan Juanito',6,11,'2021-11-10','2022-11-10','Active',NULL);
/*!40000 ALTER TABLE `officials` ENABLE KEYS */;

--
-- Table structure for table `other_details`
--

DROP TABLE IF EXISTS `other_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `other_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resident_id` int(11) DEFAULT NULL,
  `sss` varchar(50) DEFAULT NULL,
  `tin` varchar(50) DEFAULT NULL,
  `precinct` varchar(50) DEFAULT NULL,
  `gsis` varchar(50) DEFAULT NULL,
  `pagibig` varchar(50) DEFAULT NULL,
  `philhealth` varchar(50) DEFAULT NULL,
  `blood` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `other_details_ibfk_1` (`resident_id`),
  CONSTRAINT `other_details_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9567 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_details`
--

/*!40000 ALTER TABLE `other_details` DISABLE KEYS */;
INSERT INTO `other_details` VALUES (2863,2922,'','','','','','',''),(2864,2923,'','','','','','',''),(2865,2924,'','','','','','',''),(2866,2925,'','','','','','',''),(2867,2926,'','','','','','',''),(2868,2927,'','','','','','',''),(2869,2928,'','','','','','',''),(2870,2929,'','','','','','',''),(2871,2930,'','','','','','',''),(2872,2931,'','','','','','',''),(2873,2932,'','','','','','',''),(2874,2933,'','','','','','',''),(2875,2934,'','','','','','',''),(2876,2935,'','','','','','',''),(2877,2936,'','','','','','',''),(2878,2937,'','','','','','',''),(2879,2938,'','','','','','',''),(2880,2939,'','','','','','',''),(2881,2940,'','','','','','',''),(2882,2941,'','','','','','',''),(2883,2942,'','','','','','',''),(2884,2943,'','','','','','',''),(2885,2944,'','','','','','',''),(2886,2945,'','','','','','',''),(2887,2946,'','','','','','',''),(2888,2947,'','','','','','',''),(2889,2948,'','','','','','',''),(2890,2949,'','','','','','',''),(2891,2950,'','','','','','',''),(2892,2951,'','','','','','',''),(2893,2952,'','','','','','',''),(2894,2953,'','','','','','',''),(2895,2954,'','','','','','',''),(2896,2955,'','','','','','',''),(2897,2956,'','','','','','',''),(2898,2957,'','','','','','',''),(2899,2958,'','','','','','',''),(2900,2959,'','','','','','',''),(2901,2960,'','','','','','',''),(2902,2961,'','','','','','',''),(2903,2962,'','','','','','',''),(2904,2963,'','','','','','',''),(2905,2964,'','','','','','',''),(2906,2965,'','','','','','',''),(2907,2966,'','','','','','',''),(2908,2967,'','','','','','',''),(2909,2968,'','','','','','',''),(2910,2969,'','','','','','',''),(2911,2970,'','','','','','',''),(2912,2971,'','','','','','',''),(2913,2972,'','','','','','',''),(2914,2973,'','','','','','',''),(2915,2974,'','','','','','',''),(2916,2975,'','','','','','',''),(2917,2976,'','','','','','',''),(2918,2977,'','','','','','',''),(2919,2978,'','','','','','',''),(2920,2979,'','','','','','',''),(2921,2980,'','','','','','',''),(2922,2981,'','','','','','',''),(2923,2982,'','','','','','',''),(2924,2983,'','','','','','',''),(2925,2984,'','','','','','',''),(2926,2985,'','','','','','',''),(2927,2986,'','','','','','',''),(2928,2987,'','','','','','',''),(2929,2988,'','','','','','',''),(2930,2989,'','','','','','',''),(2931,2990,'','','','','','',''),(2932,2991,'','','','','','',''),(2933,2992,'','','','','','',''),(2934,2993,'','','','','','',''),(2935,2994,'','','','','','',''),(2936,2995,'','','','','','',''),(2937,2996,'','','','','','',''),(2938,2997,'','','','','','',''),(2939,2998,'','','','','','',''),(2940,2999,'','','','','','',''),(2941,3000,'','','','','','',''),(2942,3001,'','','','','','',''),(2943,3002,'','','','','','',''),(2944,3003,'','','','','','',''),(2945,3004,'','','','','','',''),(2946,3005,'','','','','','',''),(2947,3006,'','','','','','',''),(2948,3007,'','','','','','',''),(2949,3008,'','','','','','',''),(2950,3009,'','','','','','',''),(2951,3010,'','','','','','',''),(2952,3011,'','','','','','',''),(2953,3012,'','','','','','',''),(2954,3013,'','','','','','',''),(2955,3014,'','','','','','',''),(2956,3015,'','','','','','',''),(2957,3016,'','','','','','',''),(2958,3017,'','','','','','',''),(2959,3018,'','','','','','',''),(2960,3019,'','','','','','',''),(2961,3020,'','','','','','',''),(2962,3021,'','','','','','',''),(2963,3022,'','','','','','',''),(2964,3023,'','','','','','',''),(2965,3024,'','','','','','',''),(2966,3025,'','','','','','',''),(2967,3026,'','','','','','',''),(2968,3027,'','','','','','',''),(2969,3028,'','','','','','',''),(2970,3029,'','','','','','',''),(2971,3030,'','','','','','',''),(2972,3031,'','','','','','',''),(2973,3032,'','','','','','',''),(2974,3033,'','','','','','',''),(2975,3034,'','','','','','',''),(2976,3035,'','','','','','',''),(2977,3036,'','','','','','',''),(2978,3037,'','','','','','',''),(2979,3038,'','','','','','',''),(2980,3039,'','','','','','',''),(2981,3040,'','','','','','',''),(2982,3041,'','','','','','',''),(2983,3042,'','','','','','',''),(2984,3043,'','','','','','',''),(2985,3044,'','','','','','',''),(2986,3045,'','','','','','',''),(2987,3046,'','','','','','',''),(2988,3047,'','','','','','',''),(2989,3048,'','','','','','',''),(2990,3049,'','','','','','',''),(2991,3050,'','','','','','',''),(2992,3051,'','','','','','',''),(2993,3052,'','','','','','',''),(2994,3053,'','','','','','',''),(2995,3054,'','','','','','',''),(2996,3055,'','','','','','',''),(2997,3056,'','','','','','',''),(2998,3057,'','','','','','',''),(2999,3058,'','','','','','',''),(3000,3059,'','','','','','',''),(3001,3060,'','','','','','',''),(3002,3061,'','','','','','',''),(3003,3062,'','','','','','',''),(3004,3063,'','','','','','',''),(3005,3064,'','','','','','',''),(3006,3065,'','','','','','',''),(3007,3066,'','','','','','',''),(3008,3067,'','','','','','',''),(3009,3068,'','','','','','',''),(3010,3069,'','','','','','',''),(3011,3070,'','','','','','',''),(3012,3071,'','','','','','',''),(3013,3072,'','','','','','',''),(3014,3073,'','','','','','',''),(3015,3074,'','','','','','',''),(3016,3075,'','','','','','',''),(3017,3076,'','','','','','',''),(3018,3077,'','','','','','',''),(3019,3078,'','','','','','',''),(3020,3079,'','','','','','',''),(3021,3080,'','','','','','',''),(3022,3081,'','','','','','',''),(3023,3082,'','','','','','',''),(3024,3083,'','','','','','',''),(3025,3084,'','','','','','',''),(3026,3085,'','','','','','',''),(3027,3086,'','','','','','',''),(3028,3087,'','','','','','',''),(3029,3088,'','','','','','',''),(3030,3089,'','','','','','',''),(3031,3090,'','','','','','',''),(3032,3091,'','','','','','',''),(3033,3092,'','','','','','',''),(3034,3093,'','','','','','',''),(3035,3094,'','','','','','',''),(3036,3095,'','','','','','',''),(3037,3096,'','','','','','',''),(3038,3097,'','','','','','',''),(3039,3098,'','','','','','',''),(3040,3099,'','','','','','',''),(3041,3100,'','','','','','',''),(3042,3101,'','','','','','',''),(3043,3102,'','','','','','',''),(3044,3103,'','','','','','',''),(3045,3104,'','','','','','',''),(3046,3105,'','','','','','',''),(3047,3106,'','','','','','',''),(3048,3107,'','','','','','',''),(3049,3108,'','','','','','',''),(3050,3109,'','','','','','',''),(3051,3110,'','','','','','',''),(3052,3111,'','','','','','',''),(3053,3112,'','','','','','',''),(3054,3113,'','','','','','',''),(3055,3114,'','','','','','',''),(3056,3115,'','','','','','',''),(3057,3116,'','','','','','',''),(3058,3117,'','','','','','',''),(3059,3118,'','','','','','',''),(3060,3119,'','','','','','',''),(3061,3120,'','','','','','',''),(3062,3121,'','','','','','',''),(3063,3122,'','','','','','',''),(3064,3123,'','','','','','',''),(3065,3124,'','','','','','',''),(3066,3125,'','','','','','',''),(3067,3126,'','','','','','',''),(3068,3127,'','','','','','',''),(3069,3128,'','','','','','',''),(3070,3129,'','','','','','',''),(3071,3130,'','','','','','',''),(3072,3131,'','','','','','',''),(3073,3132,'','','','','','',''),(3074,3133,'','','','','','',''),(3075,3134,'','','','','','',''),(3076,3135,'','','','','','',''),(3077,3136,'','','','','','',''),(3078,3137,'','','','','','',''),(3079,3138,'','','','','','',''),(3080,3139,'','','','','','',''),(3081,3140,'','','','','','',''),(3082,3141,'','','','','','',''),(3083,3142,'','','','','','',''),(3084,3143,'','','','','','',''),(3085,3144,'','','','','','',''),(3086,3145,'','','','','','',''),(3087,3146,'','','','','','',''),(3088,3147,'','','','','','',''),(3089,3148,'','','','','','',''),(3090,3149,'','','','','','',''),(3091,3150,'','','','','','',''),(3092,3151,'','','','','','',''),(3093,3152,'','','','','','',''),(3094,3153,'','','','','','',''),(3095,3154,'','','','','','',''),(3096,3155,'','','','','','',''),(3097,3156,'','','','','','',''),(3098,3157,'','','','','','',''),(3099,3158,'','','','','','',''),(3100,3159,'','','','','','',''),(3101,3160,'','','','','','',''),(3102,3161,'','','','','','',''),(3103,3162,'','','','','','',''),(3104,3163,'','','','','','',''),(3105,3164,'','','','','','',''),(3106,3165,'','','','','','',''),(3107,3166,'','','','','','',''),(3108,3167,'','','','','','',''),(3109,3168,'','','','','','',''),(3110,3169,'','','','','','',''),(3111,3170,'','','','','','',''),(3112,3171,'','','','','','',''),(3113,3172,'','','','','','',''),(3114,3173,'','','','','','',''),(3115,3174,'','','','','','',''),(3116,3175,'','','','','','',''),(3117,3176,'','','','','','',''),(3118,3177,'','','','','','',''),(3119,3178,'','','','','','',''),(3120,3179,'','','','','','',''),(3121,3180,'','','','','','',''),(3122,3181,'','','','','','',''),(3123,3182,'','','','','','',''),(3124,3183,'','','','','','',''),(3125,3184,'','','','','','',''),(3126,3185,'','','','','','',''),(3127,3186,'','','','','','',''),(3128,3187,'','','','','','',''),(3129,3188,'','','','','','',''),(3130,3189,'','','','','','',''),(3131,3190,'','','','','','',''),(3132,3191,'','','','','','',''),(3133,3192,'','','','','','',''),(3134,3193,'','','','','','',''),(3135,3194,'','','','','','',''),(3136,3195,'','','','','','',''),(3137,3196,'','','','','','',''),(3138,3197,'','','','','','',''),(3139,3198,'','','','','','',''),(3140,3199,'','','','','','',''),(3141,3200,'','','','','','',''),(3142,3201,'','','','','','',''),(3143,3202,'','','','','','',''),(3144,3203,'','','','','','',''),(3145,3204,'','','','','','',''),(3146,3205,'','','','','','',''),(3147,3206,'','','','','','',''),(3148,3207,'','','','','','',''),(3149,3208,'','','','','','',''),(3150,3209,'','','','','','',''),(3151,3210,'','','','','','',''),(3152,3211,'','','','','','',''),(3153,3212,'','','','','','',''),(3154,3213,'','','','','','',''),(3155,3214,'','','','','','',''),(3156,3215,'','','','','','',''),(3157,3216,'','','','','','',''),(3158,3217,'','','','','','',''),(3159,3218,'','','','','','',''),(3160,3219,'','','','','','',''),(3161,3220,'','','','','','',''),(3162,3221,'','','','','','',''),(3163,3222,'','','','','','',''),(3164,3223,'','','','','','',''),(3165,3224,'','','','','','',''),(3166,3225,'','','','','','',''),(3167,3226,'','','','','','',''),(3168,3227,'','','','','','',''),(3169,3228,'','','','','','',''),(3170,3229,'','','','','','',''),(3171,3230,'','','','','','',''),(3172,3231,'','','','','','',''),(3173,3232,'','','','','','',''),(3174,3233,'','','','','','',''),(3175,3234,'','','','','','',''),(3176,3235,'','','','','','',''),(3177,3236,'','','','','','',''),(3178,3237,'','','','','','',''),(3179,3238,'','','','','','',''),(3180,3239,'','','','','','',''),(3181,3240,'','','','','','',''),(3182,3241,'','','','','','',''),(3183,3242,'','','','','','',''),(3184,3243,'','','','','','',''),(3185,3244,'','','','','','',''),(3186,3245,'','','','','','',''),(3187,3246,'','','','','','',''),(3188,3247,'','','','','','',''),(3189,3248,'','','','','','',''),(3190,3249,'','','','','','',''),(3191,3250,'','','','','','',''),(3192,3251,'','','','','','',''),(3193,3252,'','','','','','',''),(3194,3253,'','','','','','',''),(3195,3254,'','','','','','',''),(3196,3255,'','','','','','',''),(3197,3256,'','','','','','',''),(3198,3257,'','','','','','',''),(3199,3258,'','','','','','',''),(3200,3259,'','','','','','',''),(3201,3260,'','','','','','',''),(3202,3261,'','','','','','',''),(3203,3262,'','','','','','',''),(3204,3263,'','','','','','',''),(3205,3264,'','','','','','',''),(3206,3265,'','','','','','',''),(3207,3266,'','','','','','',''),(3208,3267,'','','','','','',''),(3209,3268,'','','','','','',''),(3210,3269,'','','','','','',''),(3211,3270,'','','','','','',''),(3212,3271,'','','','','','',''),(3213,3272,'','','','','','',''),(3214,3273,'','','','','','',''),(3215,3274,'','','','','','',''),(3216,3275,'','','','','','',''),(3217,3276,'','','','','','',''),(3218,3277,'','','','','','',''),(3219,3278,'','','','','','',''),(3220,3279,'','','','','','',''),(3221,3280,'','','','','','',''),(3222,3281,'','','','','','',''),(3223,3282,'','','','','','',''),(3224,3283,'','','','','','',''),(3225,3284,'','','','','','',''),(3226,3285,'','','','','','',''),(3227,3286,'','','','','','',''),(3228,3287,'','','','','','',''),(3229,3288,'','','','','','',''),(3230,3289,'','','','','','',''),(3231,3290,'','','','','','',''),(3232,3291,'','','','','','',''),(3233,3292,'','','','','','',''),(3234,3293,'','','','','','',''),(3235,3294,'','','','','','',''),(3236,3295,'','','','','','',''),(3237,3296,'','','','','','',''),(3238,3297,'','','','','','',''),(3239,3298,'','','','','','',''),(3240,3299,'','','','','','',''),(3241,3300,'','','','','','',''),(3242,3301,'','','','','','',''),(3243,3302,'','','','','','',''),(3244,3303,'','','','','','',''),(3245,3304,'','','','','','',''),(3246,3305,'','','','','','',''),(3247,3306,'','','','','','',''),(3248,3307,'','','','','','',''),(3249,3308,'','','','','','',''),(3250,3309,'','','','','','',''),(3251,3310,'','','','','','',''),(3252,3311,'','','','','','',''),(3253,3312,'','','','','','',''),(3254,3313,'','','','','','',''),(3255,3314,'','','','','','',''),(3256,3315,'','','','','','',''),(3257,3316,'','','','','','',''),(3258,3317,'','','','','','',''),(3259,3318,'','','','','','',''),(3260,3319,'','','','','','',''),(3261,3320,'','','','','','',''),(3262,3321,'','','','','','',''),(3263,3322,'','','','','','',''),(3264,3323,'','','','','','',''),(3265,3324,'','','','','','',''),(3266,3325,'','','','','','',''),(3267,3326,'','','','','','',''),(3268,3327,'','','','','','',''),(3269,3328,'','','','','','',''),(3270,3329,'','','','','','',''),(3271,3330,'','','','','','',''),(3272,3331,'','','','','','',''),(3273,3332,'','','','','','',''),(3274,3333,'','','','','','',''),(3275,3334,'','','','','','',''),(3276,3335,'','','','','','',''),(3277,3336,'','','','','','',''),(3278,3337,'','','','','','',''),(3279,3338,'','','','','','',''),(3280,3339,'','','','','','',''),(3281,3340,'','','','','','',''),(3282,3341,'','','','','','',''),(3283,3342,'','','','','','',''),(3284,3343,'','','','','','',''),(3285,3344,'','','','','','',''),(3286,3345,'','','','','','',''),(3287,3346,'','','','','','',''),(3288,3347,'','','','','','',''),(3289,3348,'','','','','','',''),(3290,3349,'','','','','','',''),(3291,3350,'','','','','','',''),(3292,3351,'','','','','','',''),(3293,3352,'','','','','','',''),(3294,3353,'','','','','','',''),(3295,3354,'','','','','','',''),(3296,3355,'','','','','','',''),(3297,3356,'','','','','','',''),(3298,3357,'','','','','','',''),(3299,3358,'','','','','','',''),(3300,3359,'','','','','','',''),(3301,3360,'','','','','','',''),(3302,3361,'','','','','','',''),(3303,3362,'','','','','','',''),(3304,3363,'','','','','','',''),(3305,3364,'','','','','','',''),(3306,3365,'','','','','','',''),(3307,3366,'','','','','','',''),(3308,3367,'','','','','','',''),(3309,3368,'','','','','','',''),(3310,3369,'','','','','','',''),(3311,3370,'','','','','','',''),(3312,3371,'','','','','','',''),(3313,3372,'','','','','','',''),(3314,3373,'','','','','','',''),(3315,3374,'','','','','','',''),(3316,3375,'','','','','','',''),(3317,3376,'','','','','','',''),(3318,3377,'','','','','','',''),(3319,3378,'','','','','','',''),(3320,3379,'','','','','','',''),(3321,3380,'','','','','','',''),(3322,3381,'','','','','','',''),(3323,3382,'','','','','','',''),(3324,3383,'','','','','','',''),(3325,3384,'','','','','','',''),(3326,3385,'','','','','','',''),(3327,3386,'','','','','','',''),(3328,3387,'','','','','','',''),(3329,3388,'','','','','','',''),(3330,3389,'','','','','','',''),(3331,3390,'','','','','','',''),(3332,3391,'','','','','','',''),(3333,3392,'','','','','','',''),(3334,3393,'','','','','','',''),(3335,3394,'','','','','','',''),(3336,3395,'','','','','','',''),(3337,3396,'','','','','','',''),(3338,3397,'','','','','','',''),(3339,3398,'','','','','','',''),(3340,3399,'','','','','','',''),(3341,3400,'','','','','','',''),(3342,3401,'','','','','','',''),(3343,3402,'','','','','','',''),(3344,3403,'','','','','','',''),(3345,3404,'','','','','','',''),(3346,3405,'','','','','','',''),(3347,3406,'','','','','','',''),(3348,3407,'','','','','','',''),(3349,3408,'','','','','','',''),(3350,3409,'','','','','','',''),(3351,3410,'','','','','','',''),(3352,3411,'','','','','','',''),(3353,3412,'','','','','','',''),(3354,3413,'','','','','','',''),(3355,3414,'','','','','','',''),(3356,3415,'','','','','','',''),(3357,3416,'','','','','','',''),(3358,3417,'','','','','','',''),(3359,3418,'','','','','','',''),(3360,3419,'','','','','','',''),(3361,3420,'','','','','','',''),(3362,3421,'','','','','','','');
/*!40000 ALTER TABLE `other_details` ENABLE KEYS */;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `details` varchar(100) DEFAULT NULL,
  `purpose` varchar(100) DEFAULT NULL,
  `amount` decimal(11,2) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `recipient` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;

--
-- Table structure for table `permit`
--

DROP TABLE IF EXISTS `permit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(100) NOT NULL,
  `owner1` varchar(100) DEFAULT NULL,
  `owner2` varchar(100) DEFAULT NULL,
  `nature` text DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `number` varchar(30) DEFAULT NULL,
  `b_address` text DEFAULT NULL,
  `o_address` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permit`
--

/*!40000 ALTER TABLE `permit` DISABLE KEYS */;
INSERT INTO `permit` VALUES (5,'IT EXPERT SOLUTIONS','ALLAN CASTANEDA \\ MATHEW GREGORIO','a','IT SERVICES','New','2025-08-19','269-1034','ALTAVAS POBLACION','KALIBO AKLAN12','APPROVED','2021-08-19'),(6,'Bakery','Jullie',NULL,'Bakery','Renewal','2021-11-10','0945848542934','Purok 2 San Vicente','San Vicente Bajo','Businessssss','2021-11-10');
/*!40000 ALTER TABLE `permit` ENABLE KEYS */;

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(50) DEFAULT NULL,
  `pos_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position`
--

/*!40000 ALTER TABLE `position` DISABLE KEYS */;
INSERT INTO `position` VALUES (1,'Councilor 1',2),(3,'PUNONG BARANGAY',1),(4,'SK Chairperson',9),(5,'Councilor 2',3),(6,'Councilor 3',4),(7,'Councilor 4',5),(8,'Councilor 5',6),(9,'Councilor 6',7),(10,'Councilor 7',8),(11,'Barangay Secretary',10),(12,'Barangay Treasurer',11),(13,'Administrative Aid',12);
/*!40000 ALTER TABLE `position` ENABLE KEYS */;

--
-- Table structure for table `precinct`
--

DROP TABLE IF EXISTS `precinct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `precinct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `precinct_name` varchar(50) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `precinct`
--

/*!40000 ALTER TABLE `precinct` DISABLE KEYS */;
INSERT INTO `precinct` VALUES (4,'1','capitol'),(5,'2','city hall');
/*!40000 ALTER TABLE `precinct` ENABLE KEYS */;

--
-- Table structure for table `purok`
--

DROP TABLE IF EXISTS `purok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purok_name` varchar(50) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purok`
--

/*!40000 ALTER TABLE `purok` DISABLE KEYS */;
INSERT INTO `purok` VALUES (7,'PUROK 1','BAYBAY'),(9,'Purok 2','');
/*!40000 ALTER TABLE `purok` ENABLE KEYS */;

--
-- Table structure for table `resident_house`
--

DROP TABLE IF EXISTS `resident_house`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resident_house` (
  `resident_id` int(11) DEFAULT NULL,
  `house_number` varchar(100) DEFAULT NULL,
  `relation` varchar(50) DEFAULT NULL,
  KEY `resident_id` (`resident_id`),
  KEY `resident_house_ibfk_2` (`house_number`),
  CONSTRAINT `resident_house_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `resident_house_ibfk_2` FOREIGN KEY (`house_number`) REFERENCES `house_number` (`number`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resident_house`
--

/*!40000 ALTER TABLE `resident_house` DISABLE KEYS */;
/*!40000 ALTER TABLE `resident_house` ENABLE KEYS */;

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `residents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(100) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `picture` text DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `alias` varchar(20) DEFAULT NULL,
  `birthplace` text DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civilstatus` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `purok` varchar(20) DEFAULT NULL,
  `voterstatus` varchar(20) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `employer_name` varchar(100) DEFAULT NULL,
  `pwd` varchar(10) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `resident_type` varchar(50) DEFAULT 'Alive',
  `remarks` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9627 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residents`
--

/*!40000 ALTER TABLE `residents` DISABLE KEYS */;
/*!40000 ALTER TABLE `residents` ENABLE KEYS */;

--
-- Table structure for table `settled`
--

DROP TABLE IF EXISTS `settled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settled` (
  `case_no` varchar(50) NOT NULL,
  `updates` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`case_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settled`
--

/*!40000 ALTER TABLE `settled` DISABLE KEYS */;
INSERT INTO `settled` VALUES ('00123','','2021-11-11'),('12324342',NULL,NULL),('12345',NULL,NULL),('13213213',NULL,NULL),('213213213',NULL,NULL),('CASESD4324234234222','','2021-06-10'),('NO3218','nice','2021-06-09');
/*!40000 ALTER TABLE `settled` ENABLE KEYS */;

--
-- Table structure for table `summon`
--

DROP TABLE IF EXISTS `summon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `summon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_no` varchar(50) DEFAULT NULL,
  `blotter_update` text DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `case_no` (`case_no`),
  CONSTRAINT `summon_ibfk_1` FOREIGN KEY (`case_no`) REFERENCES `blotter` (`case_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `summon`
--

/*!40000 ALTER TABLE `summon` DISABLE KEYS */;
INSERT INTO `summon` VALUES (6,'00123','gubot','1st','2021-11-11 16:23:00');
/*!40000 ALTER TABLE `summon` ENABLE KEYS */;

--
-- Table structure for table `support`
--

DROP TABLE IF EXISTS `support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `subject` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support`
--

/*!40000 ALTER TABLE `support` DISABLE KEYS */;
INSERT INTO `support` VALUES (2,'ALyssa','ArtElites@gmail.com','0945848542934','Remove Residents','REmove residents name blah bla','2021-12-05 13:50:33');
/*!40000 ALTER TABLE `support` ENABLE KEYS */;

--
-- Table structure for table `system_info`
--

DROP TABLE IF EXISTS `system_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(100) NOT NULL,
  `acronym` varchar(100) NOT NULL,
  `powered_b` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_info`
--

/*!40000 ALTER TABLE `system_info` DISABLE KEYS */;
INSERT INTO `system_info` VALUES (1,'Barangay Information System in San Vicente Bajo','BIS','USTP Oroquieta');
/*!40000 ALTER TABLE `system_info` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `user_type` text DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','cajan232@gmail.com1','d033e22ae348aeb5660fc2140aec35850c4da997','administrator','8ff2f7f3b500616258ecc56c88234166.png','2021-05-19 05:34:31'),(13,'staff','staff@gmail.com','6ccb4b7c39a6e77f76ecfa935a855c6c46ad5611','staff',NULL,'2021-06-24 03:33:29'),(18,'power','power@gmail.com','be1898ab2c3207298a9ead3d79f750c4646347cc','power user',NULL,'2021-08-24 23:24:40');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Dumping routines for database 'u321400137_barangay'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-24  5:46:11
